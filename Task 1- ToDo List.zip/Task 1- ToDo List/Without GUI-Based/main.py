# todo list.py

class Task:
    def __init__(self, title, description=''):
        self.title = title
        self.description = description
        self.completed = False

    def mark_complete(self):
        self.completed = True

    def __str__(self):
        status = '✔' if self.completed else '✘'
        return f"[{status}] {self.title}: {self.description}"





class ToDoList:
    def __init__(self):
        self.tasks = []

    def add_task(self, title, description=''):
        task = Task(title, description)
        self.tasks.append(task)

    def remove_task(self, index):
        if 0 <= index < len(self.tasks):
            del self.tasks[index]

    def update_task(self, index, title=None, description=None):
        if 0 <= index < len(self.tasks):
            if title:
                self.tasks[index].title = title
            if description:
                self.tasks[index].description = description

    def mark_task_complete(self, index):
        if 0 <= index < len(self.tasks):
            self.tasks[index].mark_complete()

    def list_tasks(self):
        for i, task in enumerate(self.tasks):
            print(f"{i + 1}. {task}")





def show_menu():
    print("\nTo-Do List Application")
    print("1. Add task")
    print("2. Remove task")
    print("3. Update task")
    print("4. Mark task as complete")
    print("5. List tasks")
    print("6. Exit")

def main():
    todo_list = ToDoList()
    while True:
        show_menu()
        choice = input("Choose an option: ")
        if choice == '1':
            title = input("Enter task title: ")
            description = input("Enter task description (optional): ")
            todo_list.add_task(title, description)
        elif choice == '2':
            index = int(input("Enter task number to remove: ")) - 1
            todo_list.remove_task(index)
        elif choice == '3':
            index = int(input("Enter task number to update: ")) - 1
            title = input("Enter new title (leave blank to keep current): ")
            description = input("Enter new description (leave blank to keep current): ")
            todo_list.update_task(index, title if title else None, description if description else None)
        elif choice == '4':
            index = int(input("Enter task number to mark as complete: ")) - 1
            todo_list.mark_task_complete(index)
        elif choice == '5':
            todo_list.list_tasks()
        elif choice == '6':
            break
        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()
